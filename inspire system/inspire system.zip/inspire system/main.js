// Configuration
const HOURLY_RATE = 40; // EGP per hour - change as needed
const STORAGE_KEY = "ws_clients_v1";
const INVOICE_NUMBER_KEY = "ws_invoice_number";

// State
let clients = []; // { id, name, phone, checkInTs }
let durationTimer = null;

// Elements
const form = document.getElementById("checkInForm");
const nameInput = document.getElementById("nameInput");
const phoneInput = document.getElementById("phoneInput");
const checkInInput = document.getElementById("checkInInput");
const hourlyRateLabel = document.getElementById("hourlyRateLabel");
const tbody = document.getElementById("clientsTbody");
const emptyState = document.getElementById("emptyState");

// Invoice modal elements
const invoiceModal = document.getElementById("invoiceModal");
const invoiceCloseBtn = document.getElementById("invoiceCloseBtn");
const doneInvoiceBtn = document.getElementById("doneInvoiceBtn");
const printInvoiceBtn = document.getElementById("printInvoiceBtn");
const invNumber = document.getElementById("invNumber");
const invName = document.getElementById("invName");
const invPhone = document.getElementById("invPhone");
const invDate = document.getElementById("invDate");
const invStart = document.getElementById("invStart");
const invEnd = document.getElementById("invEnd");
const invDuration = document.getElementById("invDuration");
const invRate = document.getElementById("invRate");
const invSubtotal = document.getElementById("invSubtotal");
const invTotal = document.getElementById("invTotal");
const invTotalAmount = document.getElementById("invTotalAmount");

// Utils
function formatTime(ts) {
  const d = new Date(ts);
  return d.toLocaleString("ar-EG", {
    year: 'numeric',
    month: '2-digit',
    day: '2-digit',
    hour: '2-digit',
    minute: '2-digit',
    hour12: false
  });
}

function formatDate(ts) {
  const d = new Date(ts);
  return d.toLocaleDateString("ar-EG", {
    year: 'numeric',
    month: 'long',
    day: 'numeric'
  });
}

function getNextInvoiceNumber() {
  try {
    const num = parseInt(localStorage.getItem(INVOICE_NUMBER_KEY) || "0", 10);
    const next = num + 1;
    localStorage.setItem(INVOICE_NUMBER_KEY, String(next));
    return String(next).padStart(6, '0');
  } catch (e) {
    return String(Date.now()).slice(-6);
  }
}

function formatDuration(ms) {
  const totalMinutes = Math.max(0, Math.floor(ms / 60000));
  const hours = Math.floor(totalMinutes / 60);
  const minutes = totalMinutes % 60;
  return `${hours} ساعة ${minutes} دقيقة`;
}

function calculateTotal(ms) {
  const hours = ms / (1000 * 60 * 60);
  const total = Math.ceil(hours * 100) / 100 * HOURLY_RATE; // round to 2dp for hours then multiply
  return Math.max(0, total);
}

function save() {
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(clients));
  } catch (e) {
    console.error("Failed to save to localStorage", e);
  }
}

function load() {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    clients = raw ? JSON.parse(raw) : [];
  } catch (e) {
    clients = [];
  }
}

function setDefaultCheckIn() {
  const nowLocal = new Date();
  const tzOffset = nowLocal.getTimezoneOffset();
  const localISOTime = new Date(nowLocal.getTime() - tzOffset * 60000).toISOString().slice(0, 16);
  checkInInput.value = localISOTime;
}

function render() {
  hourlyRateLabel.textContent = `${HOURLY_RATE} جنيه/ساعة`;
  tbody.innerHTML = "";
  if (!clients.length) {
    emptyState.style.display = "block";
    stopDurationTimer();
    return;
  }
  emptyState.style.display = "none";

  clients.forEach((c, idx) => {
    const tr = document.createElement("tr");
    const now = Date.now();
    const durationMs = now - c.checkInTs;

    tr.innerHTML = `
      <td>${idx + 1}</td>
      <td>${escapeHtml(c.name)}</td>
      <td dir="ltr">${escapeHtml(c.phone)}</td>
      <td>${formatTime(c.checkInTs)}</td>
      <td data-duration>${formatDuration(durationMs)}</td>
      <td>
        <button class="btn danger" data-checkout="${c.id}">🚪 تسجيل خروج</button>
      </td>
    `;
    tbody.appendChild(tr);
  });
  
  // Update durations after rendering
  updateDurations();
}

function escapeHtml(str) {
  return String(str).replace(/[&<>"']/g, s => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[s]));
}

function startDurationTimer() {
  stopDurationTimer();
  // Update immediately
  updateDurations();
  // Then update every 10 seconds for better performance
  durationTimer = setInterval(updateDurations, 10 * 1000);
}

function updateDurations() {
  const rows = tbody.querySelectorAll("tr");
  const now = Date.now();
  rows.forEach((row, i) => {
    const cell = row.querySelector('[data-duration]');
    const c = clients[i];
    if (!c || !cell) return;
    cell.textContent = formatDuration(now - c.checkInTs);
  });
}

function stopDurationTimer() {
  if (durationTimer) {
    clearInterval(durationTimer);
    durationTimer = null;
  }
}

function addClient(evt) {
  evt.preventDefault();
  const name = nameInput.value.trim();
  const phone = phoneInput.value.trim();
  const checkInLocal = checkInInput.value; // yyyy-MM-ddTHH:mm
  if (!name || !phone || !checkInLocal) return;

  const checkInTs = new Date(checkInLocal).getTime();
  const client = { id: cryptoRandomId(), name, phone, checkInTs };
  clients.push(client);
  save();
  render();
  startDurationTimer();
  form.reset();
  setDefaultCheckIn();
  nameInput.focus();
}

function cryptoRandomId() {
  if (window.crypto && crypto.getRandomValues) {
    const arr = new Uint32Array(2);
    crypto.getRandomValues(arr);
    return Array.from(arr).map(n => n.toString(16)).join("");
  }
  return String(Date.now()) + Math.random().toString(16).slice(2);
}

function onCheckout(id) {
  const idx = clients.findIndex(c => c.id === id);
  if (idx === -1) return;
  const client = clients[idx];
  const endTs = Date.now();
  const duration = endTs - client.checkInTs;
  const total = calculateTotal(duration);
  const invoiceNum = getNextInvoiceNumber();

  // Show invoice
  invNumber.textContent = `#${invoiceNum}`;
  invName.textContent = client.name;
  invPhone.textContent = client.phone;
  invDate.textContent = formatDate(endTs);
  invStart.textContent = formatTime(client.checkInTs);
  invEnd.textContent = formatTime(endTs);
  invDuration.textContent = formatDuration(duration);
  invRate.textContent = `${HOURLY_RATE} جنيه`;
  invSubtotal.textContent = `${total.toFixed(2)} جنيه`;
  invTotal.textContent = `${total.toFixed(2)} جنيه`;
  invTotalAmount.textContent = `${total.toFixed(2)} جنيه`;

  openModal();

  // Remove from list and persist
  clients.splice(idx, 1);
  save();
  render();
}

function openModal() {
  invoiceModal.classList.remove("hidden");
  invoiceModal.setAttribute("aria-hidden", "false");
}

function closeModal() {
  invoiceModal.classList.add("hidden");
  invoiceModal.setAttribute("aria-hidden", "true");
}

function onTableClick(e) {
  const btn = e.target.closest("[data-checkout]");
  if (!btn) return;
  const id = btn.getAttribute("data-checkout");
  onCheckout(id);
}

function setupEvents() {
  form.addEventListener("submit", addClient);
  document.getElementById("clientsTable").addEventListener("click", onTableClick);
  invoiceCloseBtn.addEventListener("click", closeModal);
  doneInvoiceBtn.addEventListener("click", closeModal);
  printInvoiceBtn.addEventListener("click", () => window.print());
  invoiceModal.addEventListener("click", (e) => {
    if (e.target && e.target.getAttribute("data-close") === "true") closeModal();
  });
}

function init() {
  hourlyRateLabel.textContent = `${HOURLY_RATE} جنيه/ساعة`;
  setDefaultCheckIn();
  load();
  render();
  setupEvents();
  if (clients.length) startDurationTimer();
}

document.addEventListener("DOMContentLoaded", init);


